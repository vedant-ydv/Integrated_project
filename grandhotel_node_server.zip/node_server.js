const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = 8080;
const WWWROOT = path.join(__dirname, 'Hospitality-App-main', 'GrandHotel.API', 'wwwroot');

const rooms = [
    { id: 1, name: "Ocean View Suite", roomNumber: "101", type: "Suite", price: 350.00, status: "Available" },
    { id: 2, name: "Mountain Deluxe", roomNumber: "202", type: "Deluxe", price: 220.00, status: "Available" },
    { id: 3, name: "Presidential Suite", roomNumber: "301", type: "Suite", price: 750.00, status: "Occupied" },
    { id: 4, name: "Standard Twin", roomNumber: "102", type: "Standard", price: 120.00, status: "Available" },
    { id: 5, name: "Garden View Room", roomNumber: "103", type: "Standard", price: 140.00, status: "Maintenance"},
    { id: 6, name: "Royal Penthouse", roomNumber: "501", type: "Penthouse", price: 1200.00, status: "Available" },
];

const server = http.createServer((req, res) => {
    console.log(`${req.method} ${req.url}`);

    if (req.url === '/api/rooms' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify(rooms));
    }

    if (req.url === '/api/system/info' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({
            version: "1.0.0",
            podName: os.hostname(),
            environment: process.env.APP_ENVIRONMENT || "Development"
        }));
    }

    if (req.url === '/health' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        return res.end('Healthy');
    }

    if (req.url.startsWith('/api/ai/') && (req.method === 'POST' || req.method === 'GET')) {
        const aiUrl = req.url.replace('/api/ai/', '/ai/');
        const options = {
            hostname: 'localhost',
            port: 8000,
            path: aiUrl,
            method: req.method,
            headers: req.headers
        };

        const proxy = http.request(options, (proxyRes) => {
            res.writeHead(proxyRes.statusCode, proxyRes.headers);
            proxyRes.pipe(res, { end: true });
        });

        req.pipe(proxy, { end: true });
        proxy.on('error', (err) => {
            console.error('AI Proxy Error:', err);
            res.writeHead(502);
            res.end('AI Service Unavailable');
        });
        return;
    }

    let filePath = path.join(WWWROOT, req.url === '/' ? 'index.html' : req.url);

    fs.readFile(filePath, (err, content) => {
        if (err) {
            res.writeHead(404);
            res.end('Not Found');
            return;
        }

        const ext = path.extname(filePath);
        let contentType = 'text/html';
        if (ext === '.js') contentType = 'text/javascript';
        if (ext === '.css') contentType = 'text/css';

        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
    });
});

server.listen(PORT, () => {
    console.log(`GrandHotel.API (Mock) is running at http://localhost:${PORT}`);
    console.log(`Serving static files from: ${WWWROOT}`);
});