# Hospitality-App
Orchestrate and run a Hospitality .NET API with dashboard, multimodal GenAI workflows, and agentic AI orchestration.

## Features Added
- Classic hospitality APIs: rooms and system info.
- Multimodal GenAI endpoint:
  - `POST /api/ai/visualize` -> narrative + image URL.
- Multi-agent workflow endpoint:
  - `POST /api/ai/agents/workflow` -> Researcher Agent and Writer Agent collaborative output.
- Vector memory search endpoint:
  - `POST /api/ai/memory/search` -> top-K semantic matches from hospitality knowledge memory.

## AI Configuration
Configure `Ai` in `GrandHotel.API/appsettings*.json`:
- `ApiKey`: optional. If empty, fallback/local generation is used.
- `BaseUrl`: LLM API base URL.
- `TextModel`, `ImageModel`, `EmbeddingModel`.

## Run With Docker
From repo root (`Hospitality-App-main/Hospitality-App-main`):

```bash
docker build -t hospitality-app .
docker run --rm -p 8080:8080 --name hospitality-app-run hospitality-app
```

App URLs:
- Dashboard: `http://localhost:8080`
- Swagger: `http://localhost:8080/swagger`
- Health: `http://localhost:8080/health`

## Sample API Calls

### Visualize Concept
```bash
curl -X POST "http://localhost:8080/api/ai/visualize"   -H "Content-Type: application/json"   -d "{\"prompt\":\"Luxury Resort View\"}"
```

### Run Agent Workflow
```bash
curl -X POST "http://localhost:8080/api/ai/agents/workflow"   -H "Content-Type: application/json"   -d "{\"topic\":\"Travel Itinerary\"}"
```

### Search Vector Memory
```bash
curl -X POST "http://localhost:8080/api/ai/memory/search"   -H "Content-Type: application/json"   -d "{\"query\":\"family resort activities\",\"topK\":3}"
```